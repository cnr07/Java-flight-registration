package cse212_assignment7;

public interface Expense {
	int computeExpense();

	int GetterForFlightNo();

	void DispFlightInfo();

	int getterforTicketno();

}
